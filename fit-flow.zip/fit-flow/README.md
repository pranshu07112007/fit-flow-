# FitFlow

AI-style fitness, nutrition, workout, hydration and recovery web app.

- `index.html` is the whole front end (single file, no build step). Open it in a browser.
- `supabase/schema.sql` is the database schema (profiles, logs, subscriptions with row-level security).
- `sample-data/` holds 10 made-up users for testing.

## Status
The front end currently stores everything in the browser (localStorage). Accounts, saved data and
payments are not yet connected to Supabase or a payment provider; the Plans page is a demo.
