-- FitFlow database schema (Supabase / PostgreSQL)
create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);
create table public.logs (
  user_id uuid not null references auth.users(id) on delete cascade,
  day date not null,
  data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id, day)
);
create table public.subscriptions (
  user_id uuid primary key references auth.users(id) on delete cascade,
  plan text not null default 'free' check (plan in ('free','pro','elite')),
  paid boolean not null default false,
  trial_ends_at timestamptz,
  trial_used boolean not null default false,
  updated_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.logs enable row level security;
alter table public.subscriptions enable row level security;
create policy "profiles_own_all" on public.profiles for all to authenticated
  using ((select auth.uid()) = id) with check ((select auth.uid()) = id);
create policy "logs_own_all" on public.logs for all to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
create policy "subscriptions_own_read" on public.subscriptions for select to authenticated
  using ((select auth.uid()) = user_id);
create function public.handle_new_user() returns trigger language plpgsql security definer set search_path = '' as $$
begin insert into public.subscriptions (user_id) values (new.id) on conflict do nothing; return new; end; $$;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();
revoke execute on function public.handle_new_user() from public, anon, authenticated;
create function public.start_trial(is_student boolean) returns public.subscriptions language plpgsql security definer set search_path = '' as $$
declare uid uuid := auth.uid(); row public.subscriptions;
begin
  if uid is null then raise exception 'not signed in'; end if;
  insert into public.subscriptions (user_id) values (uid) on conflict do nothing;
  update public.subscriptions set plan='pro', trial_used=true,
    trial_ends_at = now() + (case when is_student then interval '7 days' else interval '3 days' end), updated_at=now()
   where user_id=uid and trial_used=false and paid=false returning * into row;
  if row.user_id is null then select * into row from public.subscriptions where user_id=uid; end if;
  return row;
end; $$;
revoke execute on function public.start_trial(boolean) from public, anon;
grant execute on function public.start_trial(boolean) to authenticated;
